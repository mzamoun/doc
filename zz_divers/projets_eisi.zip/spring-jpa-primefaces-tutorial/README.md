CRUD example, integrating Spring 4, JPA/Hibernate, JUnit, JSF 2 and PrimeFaces 5.
