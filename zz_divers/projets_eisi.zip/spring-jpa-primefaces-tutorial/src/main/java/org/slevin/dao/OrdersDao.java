package org.slevin.dao;

import org.slevin.common.Order;

public interface OrdersDao extends EntityDao<Order>{
	
}
