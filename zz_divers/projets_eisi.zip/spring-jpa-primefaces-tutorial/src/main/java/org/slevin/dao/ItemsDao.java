package org.slevin.dao;

import org.slevin.common.Item;


public interface ItemsDao extends EntityDao<Item> {
	
}
