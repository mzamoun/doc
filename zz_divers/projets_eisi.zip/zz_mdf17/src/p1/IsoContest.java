package p1;

import java.util.*;

public class IsoContest {
	public static void main(String[] argv) throws Exception {
		String line;
		Scanner sc = new Scanner(System.in);
		int i = 0;
		int L = 0, N = 0;
		List<Integer> equip = new ArrayList<Integer>();
		int nbEt = 0;
		Vector<Integer> reste = new Vector<>();
		while (sc.hasNextLine()) {
			line = sc.nextLine();
			/* Lisez les donn�es et effectuez votre traitement */
			if (i == 0)
				L = Integer.valueOf(line);
			if (i == 1)
				N = Integer.valueOf(line);
			if (i > 1) {
				equip.add(Integer.valueOf(line));
			}
			i++;

		}
		/*
		 * Vous pouvez aussi effectuer votre traitement une fois que vous avez lu toutes
		 * les donn�es.
		 */
		// ajouter les gros

		for (int n : equip) {
			if (n == L) {
				nbEt++;
			} else {
				reste.add(n);
			}
		}

		int k=0;
		for(int i1 =0; i1< reste.size(); i1++) {
			for(int i2 =0; i2< reste.size(); i2++) {
				int n1 = reste.get(i1);
				int n2 = reste.get(i2);
				
				if(i1 != i2 && n1+n2==L) {
					k++;
				}
			}
		}
		
		nbEt += k/2;

		System.out.println(nbEt);

	}
}