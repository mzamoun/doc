insert into user(id,email,password,first_name,last_name) values (0,'rob','password','Rob','Winch');
insert into user(id,email,password,first_name,last_name) values (1,'luke','password','Luke','Taylor');
insert into user(id,email,password,first_name,last_name) values (2,'eve','password','Luke','Taylor');

update user set password = '$2a$10$FBAKClV1zBIOOC9XMXf3AO8RoGXYVYsfvUdoLxGkd/BnXEn4tqT3u';