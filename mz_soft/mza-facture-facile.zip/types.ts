
export enum DocumentType {
  QUOTE = 'devis',
  INVOICE = 'facture'
}

export enum DocumentStatus {
  DRAFT = 'brouillon',
  SENT = 'envoyé',
  PAID = 'payé',
  CANCELLED = 'annulé'
}

export interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  createdAt: string;
}

export interface LineItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  taxRate: number;
}

export interface Document {
  id: string;
  number: string;
  type: DocumentType;
  status: DocumentStatus;
  clientId: string;
  issueDate: string;
  dueDate: string;
  items: LineItem[];
  notes?: string;
  createdAt: string;
}

export interface UserProfile {
  name: string;
  companyName: string;
  email: string;
  address: string;
  siret: string;
  bankAccount: string;
  urssafFrequency: 'monthly' | 'quarterly';
  isPremium: boolean;
  subscriptionStartDate?: string;
  pendingCancellation?: boolean;
}
