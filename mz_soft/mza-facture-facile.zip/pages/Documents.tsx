
import React, { useState, useMemo } from 'react';
import { 
  Plus, 
  Search, 
  Filter, 
  Eye, 
  Download, 
  Mail, 
  Trash2, 
  MoreVertical,
  ChevronRight,
  Send,
  CheckCircle,
  Clock,
  AlertTriangle,
  FileText,
  Zap,
  ArrowRight
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { Document, DocumentType, DocumentStatus, Client, LineItem, UserProfile } from '../types';
import DocumentEditor from '../components/DocumentEditor';

interface DocumentsProps {
  type: 'devis' | 'facture';
  documents: Document[];
  setDocuments: React.Dispatch<React.SetStateAction<Document[]>>;
  clients: Client[];
  profile: UserProfile;
}

const Documents: React.FC<DocumentsProps> = ({ type, documents, setDocuments, clients, profile }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingDoc, setEditingDoc] = useState<Document | null>(null);

  const typeDocs = useMemo(() => documents.filter(d => d.type === type), [documents, type]);
  const isAtLimit = !profile.isPremium && typeDocs.length >= 1;

  const filteredDocs = useMemo(() => {
    return typeDocs
      .filter(d => {
        const client = clients.find(c => c.id === d.clientId);
        return d.number.toLowerCase().includes(searchTerm.toLowerCase()) || 
               client?.name.toLowerCase().includes(searchTerm.toLowerCase());
      })
      .sort((a, b) => new Date(b.issueDate).getTime() - new Date(a.issueDate).getTime());
  }, [typeDocs, searchTerm, clients]);

  const deleteDoc = (id: string) => {
    if (confirm(`Voulez-vous supprimer ce document ?`)) {
      setDocuments(documents.filter(d => d.id !== id));
    }
  };

  const getStatusStyle = (status: DocumentStatus) => {
    switch (status) {
      case DocumentStatus.PAID: return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case DocumentStatus.SENT: return 'bg-blue-50 text-blue-700 border-blue-200';
      case DocumentStatus.DRAFT: return 'bg-slate-100 text-slate-700 border-slate-200';
      case DocumentStatus.CANCELLED: return 'bg-rose-50 text-rose-700 border-rose-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const calculateTotal = (items: LineItem[]) => {
    return items.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);
  };

  const formatDate = (dateStr: string) => {
    return new Intl.DateTimeFormat('fr-FR').format(new Date(dateStr));
  };

  if (isEditorOpen) {
    return (
      <DocumentEditor 
        type={type as DocumentType} 
        onClose={() => { setIsEditorOpen(false); setEditingDoc(null); }}
        onSave={(doc) => {
          if (editingDoc) {
            setDocuments(prev => prev.map(d => d.id === doc.id ? doc : d));
          } else {
            setDocuments(prev => [doc, ...prev]);
          }
          setIsEditorOpen(false);
          setEditingDoc(null);
        }}
        clients={clients}
        existingDoc={editingDoc}
        nextNumber={`${type === 'devis' ? 'DEV' : 'FAC'}-${new Date().getFullYear()}-${(typeDocs.length + 1).toString().padStart(4, '0')}`}
        profile={profile}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 print:hidden">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 uppercase first-letter:capitalize">{type}s</h1>
          <p className="text-slate-500">Gérez vos {type}s et suivez leur statut.</p>
        </div>
        <button 
          onClick={() => { 
            if (!isAtLimit) {
              setEditingDoc(null); 
              setIsEditorOpen(true); 
            }
          }}
          disabled={isAtLimit}
          className={`flex items-center justify-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${isAtLimit ? 'bg-slate-100 text-slate-400 cursor-not-allowed opacity-60' : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg shadow-indigo-100'}`}
        >
          <Plus size={20} />
          <span>Nouveau {type}</span>
        </button>
      </div>

      {isAtLimit && (
        <div className="p-4 bg-indigo-50 border border-indigo-100 rounded-xl flex items-center justify-between gap-4 animate-in fade-in slide-in-from-top-2 print:hidden">
          <div className="flex items-center gap-3">
            <Zap className="text-indigo-600 fill-indigo-600" size={20} />
            <p className="text-sm font-medium text-indigo-900">Vous avez atteint la limite de 1 {type} gratuit.</p>
          </div>
          <Link to="/settings" className="flex items-center gap-1 text-sm font-bold text-indigo-600 hover:underline">
            Passer Premium <ArrowRight size={14} />
          </Link>
        </div>
      )}

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden print:hidden">
        <div className="p-4 border-b border-slate-200 flex items-center gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder={`Rechercher un ${type}...`} 
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <button className="flex items-center gap-2 px-3 py-2 border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50">
            <Filter size={18} />
            <span className="hidden sm:inline">Filtrer</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase font-semibold">
              <tr>
                <th className="px-6 py-4">N° Document</th>
                <th className="px-6 py-4">Client</th>
                <th className="px-6 py-4">Date Émission</th>
                <th className="px-6 py-4">Montant HT</th>
                <th className="px-6 py-4">Statut</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredDocs.map(doc => {
                const client = clients.find(c => c.id === doc.clientId);
                const total = calculateTotal(doc.items);
                const isOverdue = new Date(doc.dueDate) < new Date() && doc.status !== DocumentStatus.PAID;

                return (
                  <tr key={doc.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4">
                      <span className="font-bold text-indigo-600">{doc.number}</span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-col">
                        <span className="font-medium text-slate-900">{client?.name || 'Client inconnu'}</span>
                        <span className="text-xs text-slate-500">{client?.email}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-col">
                        <span className="text-sm">{formatDate(doc.issueDate)}</span>
                        {isOverdue && (
                          <span className="text-[10px] text-rose-600 font-bold uppercase flex items-center gap-1">
                            <Clock size={10} /> En retard
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="font-semibold text-slate-900">{total.toLocaleString()} €</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-semibold border ${getStatusStyle(doc.status)}`}>
                        {doc.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button 
                          onClick={() => { setEditingDoc(doc); setIsEditorOpen(true); }}
                          title="Modifier"
                          className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg"
                        >
                          <FileText size={18} />
                        </button>
                        <button 
                          title="Envoyer par email"
                          className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg"
                        >
                          <Send size={18} />
                        </button>
                        <button 
                          onClick={() => deleteDoc(doc.id)}
                          title="Supprimer"
                          className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filteredDocs.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-slate-500">
                    Aucun document trouvé. Cliquez sur "Nouveau {type}" pour commencer.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Documents;
