
import React from 'react';
import { 
  Building, 
  User, 
  Mail, 
  MapPin, 
  FileText, 
  CreditCard,
  Save,
  ShieldCheck,
  Zap,
  CheckCircle2,
  Clock,
  CalendarDays
} from 'lucide-react';
import { UserProfile } from '../types';

interface SettingsProps {
  profile: UserProfile;
  setProfile: React.Dispatch<React.SetStateAction<UserProfile>>;
}

const Settings: React.FC<SettingsProps> = ({ profile, setProfile }) => {
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const updatedProfile: UserProfile = {
      ...profile,
      name: formData.get('name') as string,
      companyName: formData.get('companyName') as string,
      email: formData.get('email') as string,
      address: formData.get('address') as string,
      siret: formData.get('siret') as string,
      bankAccount: formData.get('bankAccount') as string,
      urssafFrequency: formData.get('urssafFrequency') as 'monthly' | 'quarterly',
    };
    setProfile(updatedProfile);
    alert('Profil mis à jour !');
  };

  const handleSubscribe = () => {
    if (profile.isPremium) {
      if (profile.pendingCancellation) {
        // Reactivate
        setProfile(prev => ({ ...prev, pendingCancellation: false }));
        alert('Votre abonnement a été réactivé !');
      } else {
        // Cancel next month
        if (confirm('Souhaitez-vous vraiment vous désabonner ? Votre accès Premium restera actif jusqu\'à la fin du mois en cours.')) {
          setProfile(prev => ({ ...prev, pendingCancellation: true }));
        }
      }
    } else {
      // Subscribe
      setProfile(prev => ({ 
        ...prev, 
        isPremium: true, 
        subscriptionStartDate: new Date().toISOString(),
        pendingCancellation: false 
      }));
      alert('Félicitations ! Vous êtes maintenant Premium 🎉');
    }
  };

  const formattedStartDate = profile.subscriptionStartDate 
    ? new Date(profile.subscriptionStartDate).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })
    : null;

  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-in fade-in duration-500 pb-12">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Paramètres</h1>
          <p className="text-slate-500">Gérez vos informations professionnelles et vos préférences.</p>
        </div>
      </div>

      <section className={`bg-gradient-to-br rounded-3xl p-8 text-white shadow-2xl relative overflow-hidden transition-all duration-500 ${profile.isPremium ? (profile.pendingCancellation ? 'from-amber-600 to-orange-700' : 'from-indigo-600 to-violet-700') : 'from-slate-700 to-slate-900'}`}>
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-8">
           <div className={`p-4 rounded-2xl border ${profile.isPremium ? 'bg-white/10 border-white/20' : 'bg-slate-800 border-white/10'}`}>
             <Zap size={48} className={`fill-current ${profile.isPremium ? 'text-indigo-200' : 'text-slate-400'}`} />
           </div>
           <div className="flex-1 space-y-4">
             <div>
               <h2 className="text-2xl font-black italic uppercase tracking-tighter">
                 {profile.isPremium ? 'Plan Premium Actif' : 'Version Gratuite'}
               </h2>
               {profile.isPremium && formattedStartDate && (
                 <p className="text-indigo-100 font-medium flex items-center gap-2">
                   <CalendarDays size={14} /> Abonné depuis le {formattedStartDate}
                 </p>
               )}
               {!profile.isPremium && <p className="text-slate-400 font-medium">10€ / mois • Tout illimité</p>}
             </div>
             <ul className="space-y-2 text-sm">
               <li className="flex items-center gap-2"><CheckCircle2 size={16} className={profile.isPremium ? 'text-indigo-300' : 'text-slate-500'} /> Clients illimités</li>
               <li className="flex items-center gap-2"><CheckCircle2 size={16} className={profile.isPremium ? 'text-indigo-300' : 'text-slate-500'} /> Devis & Factures illimités</li>
               <li className="flex items-center gap-2"><CheckCircle2 size={16} className={profile.isPremium ? 'text-indigo-300' : 'text-slate-500'} /> Relances automatiques avancées</li>
             </ul>
             
             {profile.pendingCancellation && (
               <div className="p-3 bg-white/10 border border-white/20 rounded-xl flex items-center gap-2 text-xs font-bold text-amber-100 animate-pulse">
                 <Clock size={14} /> Désabonnement programmé pour la fin du mois
               </div>
             )}
           </div>
           <button 
             onClick={handleSubscribe}
             className={`px-8 py-4 rounded-2xl font-black uppercase tracking-tight transition-all active:scale-95 shadow-xl ${profile.isPremium ? (profile.pendingCancellation ? 'bg-white text-amber-700 hover:bg-amber-50' : 'bg-indigo-900/50 text-indigo-200 hover:bg-indigo-900') : 'bg-indigo-600 text-white hover:bg-indigo-500 shadow-white/10'}`}
           >
             {profile.isPremium 
               ? (profile.pendingCancellation ? 'Réactiver l\'abonnement' : 'Se désabonner le mois prochain') 
               : 'S\'abonner maintenant'}
           </button>
        </div>
        <Zap size={200} className="absolute -right-12 -bottom-12 text-white/5 rotate-12" />
      </section>

      <form onSubmit={handleSubmit} className="space-y-6">
        <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex items-center gap-3 bg-slate-50/50">
            <Building className="text-indigo-600" size={20} />
            <h2 className="font-bold text-slate-900">Mon Entreprise</h2>
          </div>
          <div className="p-6 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Nom de l'entreprise</label>
                <div className="relative">
                   <Building size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                   <input 
                     name="companyName"
                     defaultValue={profile.companyName}
                     className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500/20 focus:outline-none" 
                   />
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Numéro SIRET</label>
                <div className="relative">
                   <ShieldCheck size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                   <input 
                     name="siret"
                     defaultValue={profile.siret}
                     className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500/20 focus:outline-none" 
                   />
                </div>
              </div>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Adresse Professionnelle</label>
              <div className="relative">
                 <MapPin size={18} className="absolute left-3 top-3 text-slate-400" />
                 <textarea 
                   name="address"
                   rows={3}
                   defaultValue={profile.address}
                   className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500/20 focus:outline-none resize-none" 
                 ></textarea>
              </div>
            </div>
          </div>
        </section>

        <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex items-center gap-3 bg-slate-50/50">
            <CreditCard className="text-indigo-600" size={20} />
            <h2 className="font-bold text-slate-900">Informations de Paiement</h2>
          </div>
          <div className="p-6 space-y-4">
             <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Compte Bancaire (IBAN / Numéro)</label>
                <div className="relative">
                   <CreditCard size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                   <input 
                     name="bankAccount"
                     defaultValue={profile.bankAccount}
                     placeholder="Ex: 4970 4377 1438 2530"
                     className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500/20 focus:outline-none font-mono" 
                   />
                </div>
                <p className="mt-2 text-xs text-slate-500">Ces informations apparaîtront sur tous vos devis et factures pour faciliter le règlement.</p>
             </div>
          </div>
        </section>

        <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex items-center gap-3 bg-slate-50/50">
            <User className="text-indigo-600" size={20} />
            <h2 className="font-bold text-slate-900">Contact Personnel</h2>
          </div>
          <div className="p-6 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Nom complet</label>
                <div className="relative">
                   <User size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                   <input 
                     name="name"
                     defaultValue={profile.name}
                     className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500/20 focus:outline-none" 
                   />
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Email de contact</label>
                <div className="relative">
                   <Mail size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                   <input 
                     name="email"
                     type="email"
                     defaultValue={profile.email}
                     className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500/20 focus:outline-none" 
                   />
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex items-center gap-3 bg-slate-50/50">
            <FileText className="text-indigo-600" size={20} />
            <h2 className="font-bold text-slate-900">Préférences URSSAF</h2>
          </div>
          <div className="p-6 space-y-4">
             <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Fréquence de déclaration</label>
                <div className="grid grid-cols-2 gap-4">
                   <label className={`
                     flex items-center justify-center p-4 border-2 rounded-xl cursor-pointer transition-all
                     ${profile.urssafFrequency === 'monthly' ? 'border-indigo-600 bg-indigo-50' : 'border-slate-100 hover:border-slate-200'}
                   `}>
                     <input 
                       type="radio" 
                       name="urssafFrequency" 
                       value="monthly" 
                       className="hidden" 
                       defaultChecked={profile.urssafFrequency === 'monthly'}
                       onChange={(e) => setProfile(prev => ({...prev, urssafFrequency: 'monthly'}))}
                     />
                     <span className={`font-semibold ${profile.urssafFrequency === 'monthly' ? 'text-indigo-600' : 'text-slate-500'}`}>Mensuelle</span>
                   </label>
                   <label className={`
                     flex items-center justify-center p-4 border-2 rounded-xl cursor-pointer transition-all
                     ${profile.urssafFrequency === 'quarterly' ? 'border-indigo-600 bg-indigo-50' : 'border-slate-100 hover:border-slate-200'}
                   `}>
                     <input 
                       type="radio" 
                       name="urssafFrequency" 
                       value="quarterly" 
                       className="hidden" 
                       defaultChecked={profile.urssafFrequency === 'quarterly'}
                       onChange={(e) => setProfile(prev => ({...prev, urssafFrequency: 'quarterly'}))}
                     />
                     <span className={`font-semibold ${profile.urssafFrequency === 'quarterly' ? 'text-indigo-600' : 'text-slate-500'}`}>Trimestrielle</span>
                   </label>
                </div>
             </div>
          </div>
        </section>

        <div className="flex justify-end pt-4">
           <button 
             type="submit" 
             className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 rounded-xl font-bold shadow-xl shadow-indigo-200 transition-all active:scale-95"
           >
             <Save size={20} />
             Enregistrer les modifications
           </button>
        </div>
      </form>
    </div>
  );
};

export default Settings;
