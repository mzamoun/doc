
import React, { useMemo } from 'react';
import { 
  Users, 
  FileText, 
  Receipt, 
  TrendingUp, 
  Calendar,
  AlertCircle,
  Zap,
  ArrowRight,
  History,
  // Added CreditCard to fix the missing import error
  CreditCard
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  AreaChart, 
  Area 
} from 'recharts';
import { Client, Document, DocumentType, DocumentStatus, UserProfile } from '../types';

interface DashboardProps {
  clients: Client[];
  documents: Document[];
  profile: UserProfile;
}

const Dashboard: React.FC<DashboardProps> = ({ clients, documents, profile }) => {
  const stats = useMemo(() => {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    const invoices = documents.filter(d => d.type === DocumentType.INVOICE);
    const quotes = documents.filter(d => d.type === DocumentType.QUOTE);

    const calculateTotal = (docs: Document[]) => 
      docs.reduce((sum, doc) => 
        sum + doc.items.reduce((itemSum, item) => itemSum + (item.quantity * item.unitPrice), 0), 0
      );

    const paidInvoices = invoices.filter(i => i.status === DocumentStatus.PAID);
    const turnoverYear = calculateTotal(paidInvoices.filter(i => new Date(i.issueDate).getFullYear() === currentYear));
    const turnoverMonth = calculateTotal(paidInvoices.filter(i => {
      const d = new Date(i.issueDate);
      return d.getFullYear() === currentYear && d.getMonth() === currentMonth;
    }));

    const months = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Août', 'Sep', 'Oct', 'Nov', 'Déc'];
    const monthlyData = months.map((m, i) => {
      const monthTotal = calculateTotal(paidInvoices.filter(inv => {
        const d = new Date(inv.issueDate);
        return d.getFullYear() === currentYear && d.getMonth() === i;
      }));
      return { name: m, total: monthTotal };
    });

    const overdueCount = invoices.filter(i => {
      const isUnpaid = i.status === DocumentStatus.SENT || i.status === DocumentStatus.DRAFT;
      const isOverdue = new Date(i.dueDate) < now;
      return isUnpaid && isOverdue;
    }).length;

    return {
      totalClients: clients.length,
      totalQuotes: quotes.length,
      totalInvoices: invoices.length,
      turnoverYear,
      turnoverMonth,
      overdueCount,
      monthlyData
    };
  }, [clients, documents]);

  const showUrssafReminder = useMemo(() => {
    const today = new Date();
    const day = today.getDate();
    return profile.urssafFrequency === 'monthly' ? day >= 25 : [3, 6, 9, 12].includes(today.getMonth() + 1) && day >= 25;
  }, [profile]);

  // Calculate subscription stats
  const subscriptionStats = useMemo(() => {
    if (!profile.isPremium || !profile.subscriptionStartDate) return null;
    const start = new Date(profile.subscriptionStartDate);
    const now = new Date();
    
    // Total months including current partial month
    const diffMonths = (now.getFullYear() - start.getFullYear()) * 12 + (now.getMonth() - start.getMonth()) + 1;
    const totalPaid = diffMonths * 10;
    
    return {
      startDate: start.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' }),
      monthsActive: diffMonths,
      totalPaid
    };
  }, [profile]);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Bienvenue, {profile.name}</h1>
          <p className="text-slate-500">Voici un aperçu de votre activité pour {new Date().getFullYear()}.</p>
        </div>
        {!profile.isPremium && (
          <Link 
            to="/settings"
            className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-bold shadow-lg shadow-indigo-200 transition-all text-sm"
          >
            <Zap size={16} className="fill-white" />
            <span>Essayer Premium - 10€/mois</span>
          </Link>
        )}
      </div>

      {profile.isPremium && subscriptionStats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
           <div className="bg-white p-6 rounded-2xl border border-indigo-100 shadow-sm flex items-center gap-4">
              <div className="p-3 bg-indigo-50 rounded-xl text-indigo-600">
                <History size={24} />
              </div>
              <div>
                <p className="text-slate-500 text-xs uppercase font-bold tracking-wider">Abonné depuis le</p>
                <p className="text-lg font-bold text-slate-900">{subscriptionStats.startDate}</p>
              </div>
           </div>
           <div className="bg-white p-6 rounded-2xl border border-indigo-100 shadow-sm flex items-center gap-4">
              <div className="p-3 bg-indigo-50 rounded-xl text-indigo-600">
                <CreditCard size={24} />
              </div>
              <div>
                <p className="text-slate-500 text-xs uppercase font-bold tracking-wider">Total investi</p>
                <p className="text-lg font-bold text-slate-900">{subscriptionStats.totalPaid} €</p>
              </div>
           </div>
           {profile.pendingCancellation && (
             <div className="bg-amber-50 p-6 rounded-2xl border border-amber-100 shadow-sm flex items-center gap-4">
                <div className="p-3 bg-amber-100 rounded-xl text-amber-600">
                  <AlertCircle size={24} />
                </div>
                <div>
                  <p className="text-amber-700 text-xs uppercase font-bold tracking-wider">Résiliation</p>
                  <p className="text-sm font-semibold text-amber-900 italic">Fin de l'accès le mois prochain</p>
                </div>
             </div>
           )}
        </div>
      )}

      {!profile.isPremium && (
        <div className="bg-gradient-to-r from-slate-900 to-indigo-950 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden">
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="space-y-2 text-center md:text-left">
              <h2 className="text-xl font-bold">Version Gratuite : Vos Limites</h2>
              <div className="flex flex-wrap justify-center md:justify-start gap-4 text-xs font-medium">
                <LimitBadge label="Clients" current={stats.totalClients} limit={1} />
                <LimitBadge label="Devis" current={stats.totalQuotes} limit={1} />
                <LimitBadge label="Factures" current={stats.totalInvoices} limit={1} />
              </div>
            </div>
            <Link 
              to="/settings" 
              className="px-6 py-3 bg-white text-indigo-900 rounded-xl font-bold hover:bg-indigo-50 transition-colors flex items-center gap-2"
            >
              Débloquer l'illimité <ArrowRight size={18} />
            </Link>
          </div>
          <Zap size={120} className="absolute -right-8 -bottom-8 text-white/5 rotate-12" />
        </div>
      )}

      {showUrssafReminder && (
        <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-4">
          <div className="p-2 bg-amber-100 rounded-lg text-amber-600">
            <AlertCircle size={24} />
          </div>
          <div className="flex-1">
            <h3 className="text-amber-900 font-semibold">Rappel URSSAF</h3>
            <p className="text-amber-700 text-sm">Il est bientôt temps de déclarer votre chiffre d'affaires. Ne tardez pas !</p>
          </div>
          <button className="text-amber-600 font-medium text-sm hover:underline">Déclarer maintenant</button>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          icon={<Receipt className="text-indigo-600" />} 
          label="Chiffre d'Affaires (Mois)" 
          value={`${stats.turnoverMonth.toLocaleString()} €`} 
          trend="+12%" 
        />
        <StatCard 
          icon={<TrendingUp className="text-emerald-600" />} 
          label="CA Annuel (Objectif)" 
          value={`${stats.turnoverYear.toLocaleString()} €`} 
          trend="+5%" 
        />
        <StatCard 
          icon={<FileText className="text-amber-600" />} 
          label="Devis en attente" 
          value={stats.totalQuotes.toString()} 
        />
        <StatCard 
          icon={<AlertCircle className="text-rose-600" />} 
          label="Factures impayées" 
          value={stats.overdueCount.toString()} 
          danger={stats.overdueCount > 0}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <h2 className="text-lg font-bold mb-6">Évolution du Chiffre d'Affaires</h2>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stats.monthlyData}>
                <defs>
                  <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} tickFormatter={(value) => `${value} €`} />
                <Tooltip 
                  contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                  formatter={(value) => [`${value} €`, 'CA']}
                />
                <Area type="monotone" dataKey="total" stroke="#4f46e5" strokeWidth={3} fillOpacity={1} fill="url(#colorTotal)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col">
          <h2 className="text-lg font-bold mb-6">Répartition Clients</h2>
          <div className="flex-1 flex flex-col justify-center items-center text-center p-4">
             <div className="w-32 h-32 bg-indigo-50 rounded-full flex items-center justify-center mb-4">
                <Users size={48} className="text-indigo-600" />
             </div>
             <p className="text-3xl font-bold text-slate-900">{stats.totalClients}</p>
             <p className="text-slate-500">Clients enregistrés</p>
             <div className="w-full mt-8 space-y-3">
               <div className="flex items-center justify-between text-sm">
                 <span className="text-slate-500">Actifs</span>
                 <span className="font-semibold">{Math.round(stats.totalClients * 0.8)}</span>
               </div>
               <div className="w-full bg-slate-100 rounded-full h-2">
                 <div className="bg-indigo-600 h-2 rounded-full" style={{width: '80%'}}></div>
               </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const LimitBadge: React.FC<{ label: string, current: number, limit: number }> = ({ label, current, limit }) => (
  <div className="px-3 py-1.5 bg-white/10 rounded-lg flex items-center gap-2 border border-white/5">
    <span className="text-slate-300">{label}:</span>
    <span className={`font-bold ${current >= limit ? 'text-rose-400' : 'text-indigo-300'}`}>{current} / {limit}</span>
  </div>
);

// Fix: Added missing StatCardProps interface
interface StatCardProps {
  icon: React.ReactNode;
  label: string;
  value: string;
  trend?: string;
  danger?: boolean;
}

const StatCard: React.FC<StatCardProps> = ({ icon, label, value, trend, danger }) => (
  <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
    <div className="flex items-center justify-between mb-4">
      <div className="p-3 bg-slate-50 rounded-xl">
        {icon}
      </div>
      {trend && (
        <span className="text-xs font-medium text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full">
          {trend}
        </span>
      )}
    </div>
    <p className="text-slate-500 text-sm mb-1">{label}</p>
    <p className={`text-2xl font-bold ${danger ? 'text-rose-600' : 'text-slate-900'}`}>{value}</p>
  </div>
);

export default Dashboard;
