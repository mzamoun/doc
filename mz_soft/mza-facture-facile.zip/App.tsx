
import React, { useState, useEffect, useMemo } from 'react';
import { HashRouter, Routes, Route, Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  FileText, 
  Receipt, 
  Settings as SettingsIcon, 
  Bell, 
  LogOut,
  Menu,
  X,
  CreditCard,
  Zap
} from 'lucide-react';

import Dashboard from './pages/Dashboard';
import Clients from './pages/Clients';
import Documents from './pages/Documents';
import Settings from './pages/Settings';
import { Client, Document, UserProfile } from './types';

const INITIAL_PROFILE: UserProfile = {
  name: 'Jean Artisan',
  companyName: 'MZA Renov',
  email: 'jean@mza-renov.fr',
  address: '123 Rue de la Forge, 75000 Paris',
  siret: '123 456 789 00012',
  bankAccount: '4970 4377 1438 2530',
  urssafFrequency: 'monthly',
  isPremium: false,
  pendingCancellation: false
};

const App: React.FC = () => {
  const [clients, setClients] = useState<Client[]>([]);
  const [documents, setDocuments] = useState<Document[]>([]);
  const [profile, setProfile] = useState<UserProfile>(INITIAL_PROFILE);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Load from LocalStorage
  useEffect(() => {
    const savedClients = localStorage.getItem('mza_clients');
    const savedDocs = localStorage.getItem('mza_documents');
    const savedProfile = localStorage.getItem('mza_profile');

    if (savedClients) setClients(JSON.parse(savedClients));
    if (savedDocs) setDocuments(JSON.parse(savedDocs));
    if (savedProfile) {
      const parsed = JSON.parse(savedProfile);
      // Ensure bankAccount exists in loaded profile
      if (!parsed.bankAccount) parsed.bankAccount = INITIAL_PROFILE.bankAccount;
      setProfile(parsed);
    }
  }, []);

  // Sync to LocalStorage
  useEffect(() => {
    localStorage.setItem('mza_clients', JSON.stringify(clients));
  }, [clients]);

  useEffect(() => {
    localStorage.setItem('mza_documents', JSON.stringify(documents));
  }, [documents]);

  useEffect(() => {
    localStorage.setItem('mza_profile', JSON.stringify(profile));
  }, [profile]);

  return (
    <HashRouter>
      <div className="flex h-screen bg-slate-50 overflow-hidden">
        {/* Mobile Sidebar Overlay */}
        {isSidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={() => setIsSidebarOpen(false)}
          />
        )}

        {/* Sidebar */}
        <aside className={`
          fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 text-white transform transition-transform duration-300 ease-in-out lg:relative lg:translate-x-0
          ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
        `}>
          <div className="flex flex-col h-full">
            <div className="p-6 flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center font-bold text-xl">M</div>
              <h1 className="font-bold text-lg tracking-tight">Facture Facile</h1>
            </div>

            <nav className="flex-1 px-4 space-y-1 mt-4">
              <SidebarLink to="/" icon={<LayoutDashboard size={20} />} label="Tableau de bord" onClick={() => setIsSidebarOpen(false)} />
              <SidebarLink to="/clients" icon={<Users size={20} />} label="Clients" onClick={() => setIsSidebarOpen(false)} />
              <SidebarLink to="/quotes" icon={<FileText size={20} />} label="Devis" onClick={() => setIsSidebarOpen(false)} />
              <SidebarLink to="/invoices" icon={<Receipt size={20} />} label="Factures" onClick={() => setIsSidebarOpen(false)} />
              <SidebarLink to="/settings" icon={<SettingsIcon size={20} />} label="Paramètres" onClick={() => setIsSidebarOpen(false)} />
            </nav>

            <div className="p-4 space-y-4">
              {!profile.isPremium && (
                <Link 
                  to="/settings"
                  onClick={() => setIsSidebarOpen(false)}
                  className="block p-4 bg-gradient-to-br from-indigo-600 to-violet-700 rounded-xl shadow-lg shadow-indigo-900/20 group hover:scale-[1.02] transition-transform"
                >
                  <div className="flex items-center gap-2 text-white font-bold mb-1">
                    <Zap size={16} className="fill-white" />
                    <span className="text-sm">Passer Premium</span>
                  </div>
                  <p className="text-[11px] text-indigo-100 leading-tight">Illimité pour seulement 10€/mois. Gérez tout sans limites.</p>
                </Link>
              )}

              <div className="pt-4 border-t border-slate-800">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 bg-slate-700 rounded-full flex items-center justify-center text-xs">JA</div>
                  <div className="overflow-hidden">
                    <p className="text-sm font-medium truncate">{profile.name}</p>
                    <p className="text-xs text-slate-400 truncate">{profile.companyName}</p>
                  </div>
                </div>
                <button className="flex items-center gap-3 w-full px-3 py-2 text-sm text-slate-400 hover:text-white transition-colors">
                  <LogOut size={18} />
                  <span>Déconnexion</span>
                </button>
              </div>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
          {/* Header */}
          <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 lg:px-8">
            <button 
              className="lg:hidden p-2 text-slate-500 hover:bg-slate-100 rounded-lg"
              onClick={() => setIsSidebarOpen(true)}
            >
              <Menu size={24} />
            </button>

            <div className="flex items-center gap-4">
              {profile.isPremium && (
                <span className={`hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border uppercase tracking-wider ${profile.pendingCancellation ? 'bg-amber-50 text-amber-700 border-amber-100' : 'bg-indigo-50 text-indigo-700 border-indigo-100'}`}>
                  <Zap size={12} className={profile.pendingCancellation ? 'fill-amber-600' : 'fill-indigo-600'} />
                  {profile.pendingCancellation ? 'Finit bientôt' : 'Premium'}
                </span>
              )}
              <div className="relative">
                <button className="p-2 text-slate-500 hover:bg-slate-100 rounded-full">
                  <Bell size={20} />
                  <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
                </button>
              </div>
            </div>
          </header>

          <div className="flex-1 overflow-y-auto p-4 lg:p-8">
            <Routes>
              <Route path="/" element={<Dashboard clients={clients} documents={documents} profile={profile} />} />
              <Route path="/clients" element={<Clients clients={clients} setClients={setClients} profile={profile} />} />
              <Route path="/quotes" element={<Documents type="devis" documents={documents} setDocuments={setDocuments} clients={clients} profile={profile} />} />
              <Route path="/invoices" element={<Documents type="facture" documents={documents} setDocuments={setDocuments} clients={clients} profile={profile} />} />
              <Route path="/settings" element={<Settings profile={profile} setProfile={setProfile} />} />
            </Routes>
          </div>
        </main>
      </div>
    </HashRouter>
  );
};

interface SidebarLinkProps {
  to: string;
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
}

const SidebarLink: React.FC<SidebarLinkProps> = ({ to, icon, label, onClick }) => {
  const location = useLocation();
  const isActive = location.pathname === to || (to !== '/' && location.pathname.startsWith(to));

  return (
    <Link
      to={to}
      onClick={onClick}
      className={`
        flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all
        ${isActive ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}
      `}
    >
      {icon}
      <span>{label}</span>
    </Link>
  );
};

export default App;
