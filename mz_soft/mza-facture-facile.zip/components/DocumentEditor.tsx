
import React, { useState } from 'react';
import { 
  X, 
  Plus, 
  Trash2, 
  Save, 
  FileText, 
  Calendar, 
  User, 
  Package,
  ArrowLeft,
  Download,
  CreditCard
} from 'lucide-react';
import { Document, DocumentType, DocumentStatus, Client, LineItem, UserProfile } from '../types';

interface DocumentEditorProps {
  type: DocumentType;
  clients: Client[];
  onClose: () => void;
  onSave: (doc: Document) => void;
  existingDoc: Document | null;
  nextNumber: string;
  profile: UserProfile;
}

const DocumentEditor: React.FC<DocumentEditorProps> = ({ type, clients, onClose, onSave, existingDoc, nextNumber, profile }) => {
  const [clientId, setClientId] = useState(existingDoc?.clientId || '');
  const [issueDate, setIssueDate] = useState(existingDoc?.issueDate || new Date().toISOString().split('T')[0]);
  const [dueDate, setDueDate] = useState(existingDoc?.dueDate || '');
  const [status, setStatus] = useState(existingDoc?.status || DocumentStatus.DRAFT);
  const [items, setItems] = useState<LineItem[]>(existingDoc?.items || [
    { id: crypto.randomUUID(), description: '', quantity: 1, unitPrice: 0, taxRate: 20 }
  ]);
  const [notes, setNotes] = useState(existingDoc?.notes || '');

  const addItem = () => {
    setItems([...items, { id: crypto.randomUUID(), description: '', quantity: 1, unitPrice: 0, taxRate: 20 }]);
  };

  const removeItem = (id: string) => {
    if (items.length > 1) {
      setItems(items.filter(i => i.id !== id));
    }
  };

  const updateItem = (id: string, field: keyof LineItem, value: string | number) => {
    setItems(items.map(i => i.id === id ? { ...i, [field]: value } : i));
  };

  const calculateSubtotal = () => {
    return items.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientId) {
      alert('Veuillez sélectionner un client.');
      return;
    }

    const doc: Document = {
      id: existingDoc?.id || crypto.randomUUID(),
      number: existingDoc?.number || nextNumber,
      type,
      status,
      clientId,
      issueDate,
      dueDate: dueDate || issueDate,
      items,
      notes,
      createdAt: existingDoc?.createdAt || new Date().toISOString()
    };
    onSave(doc);
  };

  return (
    <div className="max-w-4xl mx-auto pb-12 animate-in slide-in-from-bottom-4 duration-300">
      <div className="flex items-center justify-between mb-8 print:hidden">
        <button onClick={onClose} className="flex items-center gap-2 text-slate-500 hover:text-slate-900 transition-colors">
          <ArrowLeft size={20} />
          <span>Retour à la liste</span>
        </button>
        <div className="flex gap-3">
          <button 
            type="button" 
            className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 font-medium"
            onClick={() => window.print()}
          >
            <Download size={18} />
            PDF
          </button>
          <button 
            onClick={handleSave}
            className="flex items-center gap-2 px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 font-bold shadow-lg shadow-indigo-100 transition-all"
          >
            <Save size={18} />
            Enregistrer
          </button>
        </div>
      </div>

      <form className="space-y-6">
        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm space-y-8 print:shadow-none print:border-none print:p-0">
          <div className="flex flex-col md:flex-row justify-between gap-8">
            <div className="space-y-4 flex-1">
               <div className="flex items-center gap-3">
                 <div className="p-2 bg-indigo-50 rounded-lg text-indigo-600 print:hidden">
                   <FileText size={20} />
                 </div>
                 <h2 className="text-xl font-bold uppercase">{type} {existingDoc?.number || nextNumber}</h2>
               </div>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 <div>
                    <label className="block text-xs font-semibold text-slate-400 uppercase mb-1">Date d'émission</label>
                    <input 
                      type="date" 
                      value={issueDate}
                      onChange={(e) => setIssueDate(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 print:border-none print:p-0"
                    />
                 </div>
                 <div>
                    <label className="block text-xs font-semibold text-slate-400 uppercase mb-1">Date d'échéance</label>
                    <input 
                      type="date" 
                      value={dueDate}
                      onChange={(e) => setDueDate(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 print:border-none print:p-0"
                    />
                 </div>
               </div>
               <div className="print:hidden">
                  <label className="block text-xs font-semibold text-slate-400 uppercase mb-1">Statut</label>
                  <select 
                    value={status}
                    onChange={(e) => setStatus(e.target.value as DocumentStatus)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  >
                    <option value={DocumentStatus.DRAFT}>Brouillon</option>
                    <option value={DocumentStatus.SENT}>Envoyé</option>
                    <option value={DocumentStatus.PAID}>Payé</option>
                    <option value={DocumentStatus.CANCELLED}>Annulé</option>
                  </select>
               </div>
            </div>

            <div className="space-y-4 flex-1">
               <div className="flex items-center gap-3">
                 <div className="p-2 bg-slate-50 rounded-lg text-slate-600 print:hidden">
                   <User size={20} />
                 </div>
                 <h2 className="text-xl font-bold">Client</h2>
               </div>
               <select 
                 value={clientId}
                 onChange={(e) => setClientId(e.target.value)}
                 className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 print:hidden"
                 required
               >
                 <option value="">Sélectionner un client...</option>
                 {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
               </select>
               {clientId && (
                 <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 text-sm print:bg-white print:border-none print:p-0">
                    <p className="font-semibold">{clients.find(c => c.id === clientId)?.name}</p>
                    <p className="text-slate-500 whitespace-pre-wrap">{clients.find(c => c.id === clientId)?.address}</p>
                 </div>
               )}
            </div>
          </div>

          <div className="border-t border-slate-100 pt-8 print:pt-4">
             <div className="flex items-center justify-between mb-4 print:mb-2">
               <h3 className="text-lg font-bold flex items-center gap-2">
                 <Package size={18} className="text-slate-400 print:hidden" />
                 Détails des prestations
               </h3>
               <button 
                 type="button" 
                 onClick={addItem}
                 className="text-sm text-indigo-600 font-semibold flex items-center gap-1 hover:underline print:hidden"
               >
                 <Plus size={16} /> Ajouter une ligne
               </button>
             </div>

             <div className="space-y-4 print:space-y-2">
                <div className="hidden print:grid grid-cols-12 gap-3 pb-2 border-b border-slate-200 text-xs font-bold text-slate-400 uppercase">
                  <div className="col-span-6">Description</div>
                  <div className="col-span-2 text-center">Qté</div>
                  <div className="col-span-2 text-right">PU HT</div>
                  <div className="col-span-2 text-right">Total HT</div>
                </div>
                {items.map((item, index) => (
                  <div key={item.id} className="grid grid-cols-12 gap-3 items-end print:items-start">
                    <div className="col-span-12 md:col-span-5 print:col-span-6">
                       <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1 print:hidden">Description</label>
                       <input 
                         type="text" 
                         placeholder="Ex: Main d'oeuvre installation" 
                         value={item.description}
                         onChange={(e) => updateItem(item.id, 'description', e.target.value)}
                         className="w-full px-3 py-2 border border-slate-200 rounded-lg print:border-none print:p-0 print:text-sm"
                       />
                    </div>
                    <div className="col-span-4 md:col-span-2 print:col-span-2">
                       <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1 print:hidden">Qté</label>
                       <input 
                         type="number" 
                         value={item.quantity}
                         onChange={(e) => updateItem(item.id, 'quantity', parseFloat(e.target.value))}
                         className="w-full px-3 py-2 border border-slate-200 rounded-lg print:border-none print:p-0 print:text-center print:text-sm"
                       />
                    </div>
                    <div className="col-span-4 md:col-span-2 print:col-span-2">
                       <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1 print:hidden">Prix Unitaire</label>
                       <input 
                         type="number" 
                         value={item.unitPrice}
                         onChange={(e) => updateItem(item.id, 'unitPrice', parseFloat(e.target.value))}
                         className="w-full px-3 py-2 border border-slate-200 rounded-lg print:border-none print:p-0 print:text-right print:text-sm"
                       />
                    </div>
                    <div className="col-span-3 md:col-span-2 text-right print:col-span-2">
                       <p className="text-[10px] font-bold text-slate-400 uppercase mb-2 print:hidden">Sous-total</p>
                       <span className="font-bold text-slate-900 print:text-sm">{(item.quantity * item.unitPrice).toLocaleString()} €</span>
                    </div>
                    <div className="col-span-1 print:hidden">
                      <button 
                        type="button" 
                        onClick={() => removeItem(item.id)}
                        className="p-2 text-slate-300 hover:text-rose-600 transition-colors"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                ))}
             </div>
          </div>

          <div className="border-t border-slate-100 pt-8 flex flex-col md:flex-row gap-8 print:pt-4">
            <div className="flex-1 space-y-6">
              <div className="space-y-2">
                <label className="block text-sm font-bold text-slate-700 print:text-xs">Notes & Conditions</label>
                <textarea 
                  rows={4} 
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Ex: Paiement par virement bancaire sous 30 jours..."
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 resize-none print:border-none print:p-0 print:text-xs print:h-auto"
                ></textarea>
              </div>

              <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-100 space-y-2 print:bg-white print:border-slate-200 print:p-4">
                <div className="flex items-center gap-2 text-indigo-700 mb-2 print:text-slate-900">
                  <CreditCard size={18} />
                  <h4 className="font-bold text-sm uppercase tracking-wider">Coordonnées Bancaires</h4>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-indigo-600 font-medium print:text-slate-500">Bénéficiaire :</span>
                  <span className="text-sm font-bold text-indigo-900 print:text-slate-900">{profile.companyName}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-indigo-600 font-medium print:text-slate-500">Compte :</span>
                  <span className="text-sm font-mono font-bold text-indigo-900 print:text-slate-900">{profile.bankAccount}</span>
                </div>
              </div>
            </div>

            <div className="w-full md:w-72 bg-slate-50 p-6 rounded-2xl border border-slate-100 space-y-4 h-fit print:bg-white print:border-slate-200 print:p-4">
               <div className="flex justify-between items-center text-slate-500 print:text-xs">
                 <span>Total HT</span>
                 <span>{calculateSubtotal().toLocaleString()} €</span>
               </div>
               <div className="flex justify-between items-center text-slate-500 print:text-xs">
                 <span>TVA (0% - Auto-ent)</span>
                 <span>0 €</span>
               </div>
               <div className="pt-4 border-t border-slate-200 flex justify-between items-center">
                 <span className="text-lg font-bold print:text-sm">Total TTC</span>
                 <span className="text-2xl font-black text-indigo-600 print:text-lg">{calculateSubtotal().toLocaleString()} €</span>
               </div>
            </div>
          </div>
        </div>
      </form>

      <div className="mt-8 text-center text-slate-400 text-[10px] hidden print:block">
        <p>{profile.companyName} - SIRET : {profile.siret}</p>
        <p>{profile.address}</p>
        <p>Document généré par mza-facture-facile</p>
      </div>
    </div>
  );
};

export default DocumentEditor;
